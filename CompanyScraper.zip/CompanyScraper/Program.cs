﻿using HtmlAgilityPack;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net;
using System.Text;
using System.IO;
using System.Reflection;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.VisualBasic.FileIO;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using System.Data;
using CsvHelper;
using System.Formats.Asn1;
using System.Globalization;

int number1 = 0;
int number2 = 0;
int number3 = 0;
int number4 = 0;
int number5 = 0;

//get the urls to list
List<string[]> dataList = new List<string[]>();

string filePath = @"/Users/Guest123/Desktop/data/1.csv";

using (var reader = new StreamReader(filePath))
{
    while (!reader.EndOfStream)
    {
        string[] line = reader.ReadLine().Split(';');
        dataList.Add(line);
    }
}
string[] dataListArray = dataList.SelectMany(x => x).ToArray();

//creating a string builder
var csv = new StringBuilder();
csv.AppendLine("Name,StreetAddress1,StreetAddress2,AddressLocality,PostalCode,Phone,LogoUrl");

File.Delete(@"/Users/Guest123/Desktop/data/companies.csv");
//increase the site
int number = 0;


foreach (string val in dataListArray)
{
    int index = 1;

    while (true)
    {

        string baseUrl = $"www.solarguide.co.uk{val}{index}";
        string url = $"https://api.scrapingant.com/v2/general?url=https%3A%2F%2F{baseUrl}%23%2F&x-api-key=d215b5564fd148c1b73b49c8b3c0212a&browser=false";
        using (HttpClient client = new HttpClient())
        {
            HttpResponseMessage response = await client.GetAsync(url);
            string htmlContent = await response.Content.ReadAsStringAsync();

            // Parse the HTML content using HtmlAgilityPack
            HtmlDocument htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(htmlContent);

            // Select all items with the specified itemtype
            var items = htmlDoc.DocumentNode.SelectNodes("//div[@itemtype='http://schema.org/Organization']");

            if (items == null || items.Count == 0)
            {
                Console.WriteLine("No items found with the specified itemtype.");
                break;
            }

            // Iterate through each item and extract the required details
            foreach (var item in items)
            {
                var nameNode = item.SelectSingleNode(".//h3[@itemprop='name']/a");
                var streetAddressNodes = item.SelectNodes(".//p[@itemprop='address']//span[@itemprop='streetAddress']");
                var localityNode = item.SelectSingleNode(".//p[@itemprop='address']//span[@itemprop='addressLocality']");
                var postalCodeNode = item.SelectSingleNode(".//p[@itemprop='address']//span[@itemprop='postalCode']");
                var phoneNode = item.SelectSingleNode(".//p[@class='phone']/span[@itemprop='telephone']");


                // Extract the data
                var name = nameNode?.InnerText.Trim() ?? string.Empty;
                var streetAddress1 = streetAddressNodes?.Count > 0 ? streetAddressNodes[0].InnerText.Trim() : string.Empty;
                var streetAddress2 = streetAddressNodes?.Count > 1 ? streetAddressNodes[1].InnerText.Trim() : string.Empty;
                var locality = localityNode?.InnerText.Trim() ?? string.Empty;
                var postalCode = postalCodeNode?.InnerText.Trim() ?? string.Empty;
                var phone = phoneNode?.InnerText.Trim() ?? string.Empty;

                // Append the extracted data to the CSV
                csv.AppendLine($"{EscapeCsvValue(name)},{EscapeCsvValue(streetAddress1)},{EscapeCsvValue(streetAddress2)},{EscapeCsvValue(locality)},{EscapeCsvValue(postalCode)},{EscapeCsvValue(phone)},{EscapeCsvValue(baseUrl)}");
            }
            index++;
        }
    }
    File.AppendAllText(@"/Users/Guest123/Desktop/data/companies.csv", csv.ToString());
    csv.Clear();
}
// Helper method to escape CSV values
static string EscapeCsvValue(string value)
{
    if (string.IsNullOrEmpty(value))
        return string.Empty;

    // Escape double quotes
    value = value.Replace("\"", "\"\"");

    // Surround value with double quotes if it contains a comma, new line, or double quote
    if (value.Contains(",") || value.Contains("\n") || value.Contains("\""))
    {
        value = $"\"{value}\"";
    }

    return value;

}