﻿using HtmlAgilityPack;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net;
using System.Text;
using System.IO;
using System.Reflection;


//https://www.solarguide.co.uk/location/united-kingdom#/


String url = "https://api.scrapingant.com/v2/general?url=https%3A%2F%2Fwww.solarguide.co.uk%2Flocation%2Funited-kingdom%23%2F&x-api-key=d215b5564fd148c1b73b49c8b3c0212a&browser=false";
var httpClient = new HttpClient();
var html = httpClient.GetStringAsync(url).Result;
var htmlDocument = new HtmlDocument();
htmlDocument.LoadHtml(html);

List<string> hodnoty = new List<string>();

//get the region url
var regionUrls = htmlDocument.DocumentNode.SelectNodes("//div[@class='sixcol area-list first clearfix']//ul//li//a");

//if not null
if (regionUrls != null)
{
    foreach (var regiony in regionUrls)
    {
        // Get the value of href attribute
        string hrefValue = regiony.GetAttributeValue("href", "");
        Console.WriteLine(hrefValue);

        hodnoty.Add(hrefValue);
    }
}
else
{
    Console.WriteLine("No anchor elements found.");
}

string[] hodnotyArray = hodnoty.ToArray();

//zapiš do csv
String file = @"/Users/josefnavratil/Desktop/regiony.csv";
StringBuilder sb = new StringBuilder();

foreach(string hodnota in hodnotyArray)
{
    sb.AppendLine(hodnota);

}
try
{
    File.WriteAllText(file, sb.ToString());

    Console.WriteLine("Data byla úspěšně zapsána do souboru: " + file);
}
catch(Exception ex)
{
    Console.WriteLine($"Chyba{ex}");
}


foreach (string regionUrl in hodnotyArray)
{
    var regionHtml = httpClient.GetStringAsync(regionUrl).Result;
    var regionHtmlDocument = new HtmlDocument();
    regionHtmlDocument.LoadHtml(regionHtml);
}

    static void zkouska()
{

}

//get the area url

//for each area fetch [Name, Profile url, Addresse, Phone number]


