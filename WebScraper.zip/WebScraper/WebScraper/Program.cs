﻿using HtmlAgilityPack;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net;
using System.Text;
using System.IO;
using System.Reflection;


//https://www.solarguide.co.uk/location/united-kingdom#/

List<string> hodnoty = new List<string>();

string url = "https://api.scrapingant.com/v2/general?url=https%3A%2F%2Fwww.solarguide.co.uk%2Flocation%2Funited-kingdom%23%2F&x-api-key=d215b5564fd148c1b73b49c8b3c0212a&browser=false";
var httpClient = new HttpClient();
var html = httpClient.GetStringAsync(url).Result;
var htmlDocument = new HtmlDocument();
htmlDocument.LoadHtml(html);



//get the region url
var regionUrls = htmlDocument.DocumentNode.SelectNodes("//div[@class='sixcol area-list first clearfix']//ul//li//a");

//if not null
if (regionUrls != null)
{
    foreach (var regiony in regionUrls)
    {
        // Get the value of href attribute
        string hrefValue = regiony.GetAttributeValue("href", "");
        Console.WriteLine(hrefValue);

        hodnoty.Add(hrefValue);
    }
}
else
{
    Console.WriteLine("No anchor elements found.");
    Environment.Exit(0);
}

string[] hodnotyArray = hodnoty.ToArray();

//zapiš do csv
string file = @"/Users/Guest123/Desktop/data/regiony.csv";
StringBuilder sb = new StringBuilder();

foreach(string hodnota in hodnotyArray)
{
    sb.AppendLine(hodnota);

}
try
{
    File.WriteAllText(file, sb.ToString());

    Console.WriteLine("Data byla úspěšně zapsána do souboru: " + file);
}
catch(Exception ex)
{
    Console.WriteLine($"Chyba{ex}");
}

//get the area url
List<string> areaList = new List<string>();

foreach (var x in hodnotyArray)
{
    string url1 = $"https://api.scrapingant.com/v2/general?url=https%3A%2F%2Fwww.solarguide.co.uk{x}%23%2F&x-api-key=d215b5564fd148c1b73b49c8b3c0212a";
    var html1 = httpClient.GetStringAsync(url1).Result;
    htmlDocument.LoadHtml(html1);


    var areaUrls = htmlDocument.DocumentNode.SelectNodes("//div[@class='sixcol area-list first clearfix']//ul//li//a");
    if (areaUrls != null)
    {
        foreach(var area in areaUrls)
        {
            string hrefValue = area.GetAttributeValue("href", "");
            Console.WriteLine(hrefValue);

            areaList.Add(hrefValue);
        }
    }
    else
    {
        Console.WriteLine("No anchor elements found.");
        
    }


}

string[] areaArray = areaList.ToArray();

string file1 = @"/Users/Guest123/Desktop/data/area.csv";
StringBuilder sb1 = new StringBuilder();

foreach (string value in areaArray)
{
    sb1.AppendLine(value);

}
try
{
    File.WriteAllText(file1, sb1.ToString());

    Console.WriteLine("Data byla úspěšně zapsána do souboru: " + file1);
}
catch (Exception ex)
{
    Console.WriteLine($"Chyba{ex}");
}


